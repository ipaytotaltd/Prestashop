<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class Ipaytotal extends PaymentModule
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'ipaytotal';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->author = 'nalezny.cz';
        $this->need_instance = 0;

        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('ipaytotal');
        $this->description = $this->l('Ipaytotal Payment solutions to win you more customers !');

        $this->limited_currencies = array('EUR');

        $this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);
    }

    public function install()
    {
        Configuration::updateValue('IPAYTOTAL_LIVE_MODE', false);
        Configuration::updateValue('IPAYTOTAL_API_KEY', '');
        

        return parent::install() &&
            $this->registerHook('header') &&
            $this->registerHook('backOfficeHeader') &&
            $this->registerHook('payment') &&
            $this->registerHook('paymentOptions') &&
            $this->registerHook('paymentReturn');
    }

    public function uninstall()
    {
        return parent::uninstall();
    }

    public function getContent()
    {
        if (((bool)Tools::isSubmit('submitIpaytotalModule')) == true) {
            $this->postProcess();
        }

        return $this->renderForm();
    }

    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitIpaytotalModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    protected function getConfigForm()
    {
        return array(
            'form' => array(
                'legend' => array(
                'title' => $this->l('Settings'),
                'icon' => 'icon-cogs',
                ),
                'input' => array(
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Live mode'),
                        'name' => 'IPAYTOTAL_LIVE_MODE',
                        'is_bool' => true,
                        'desc' => $this->l('Use this module in live mode'),
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => true,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => false,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'type' => 'text',
                        'desc' => $this->l('Enter API KEY'),
                        'name' => 'IPAYTOTAL_API_KEY',
                        'label' => $this->l('API KEY'),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
    }

    protected function getConfigFormValues()
    {
        return array(
            'IPAYTOTAL_LIVE_MODE' => Configuration::get('IPAYTOTAL_LIVE_MODE'),
            'IPAYTOTAL_API_KEY' => Configuration::get('IPAYTOTAL_API_KEY')
        );
    }

    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();
        
        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
        }
    }

    public function hookHeader()
    {
        $this->context->controller->addJS($this->_path.'/views/js/front.js');
        $this->context->controller->addCSS($this->_path.'/views/css/front.css');
        
        $this->context->controller->addJS($this->_path.'/views/js/card-js.min.js');
        $this->context->controller->addCSS($this->_path.'/views/css/card-js.min.css');
    }

    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        // $currency_id = $params['cart']->id_currency;
        // $currency = new Currency((int)$currency_id);

        // $cart = new Cart($params['cart']->id);
        // $total = $cart->getOrderTotal();

        // $ipaytotal_reference = Order::generateReference();
        // $this->context->cookie->__set('ipaytotal_reference', $ipaytotal_reference);
        // $this->context->cookie->write();

        $customer = new Customer($params['cart']->id_customer);

        // $this->smarty->assign('email', $customer->email);
        $this->context->smarty->assign('name', $customer->firstname.' '.$customer->lastname);

        // $this->smarty->assign('module_dir', $this->_path);
        // $this->smarty->assign('total', $total);

        // $link = new Link();
        // $cms_link = $link->getCMSLink('9', null, null, $this->context->cookie->id_lang);
        // $this->smarty->assign('cms_link', $cms_link);        

        // $config['date'] = '%M:%I %p';
        // $config['time'] = '%H:%M:%S';
        // $this->smarty->assign('config', $config);
        // $this->smarty->assign('yesterday', strtotime('0 day'));

        // if (in_array($currency->iso_code, $this->limited_currencies) == false)
        //     return false;

        // $this->smarty->assign('module_dir', $this->_path);
        // $this->smarty->assign('ipaytotal_reference', $ipaytotal_reference);

        $newOption = new PaymentOption();
        $newOption->setModuleName($this->name)
            ->setCallToActionText(
                $this->trans(
                    'Ipaytotal - Pay by Credit card',
                    array(),
                    'Modules.wasakredit.Admin'
                )
            )
            ->setAction(
                $this->context->link->getModuleLink(
                    $this->name,
                    'payment',
                    array(),
                    true
                )
            )
            ->setAdditionalInformation(
                $this->fetch('module:ipaytotal/views/templates/hook/payment.tpl')
            );

        return array($newOption);
    }

    public function hookPayment($params)
    {
        $currency_id = $params['cart']->id_currency;
        $currency = new Currency((int)$currency_id);

        $cart = new Cart($params['cart']->id);
        $total = $cart->getOrderTotal();

        $ipaytotal_reference = Order::generateReference();
        $this->context->cookie->__set('ipaytotal_reference', $ipaytotal_reference);
        $this->context->cookie->write();

        $customer = new Customer($params['cart']->id_customer);

        $this->smarty->assign('email', $customer->email);
        $this->smarty->assign('name', $customer->firstname.' '.$customer->lastname);
        $this->smarty->assign('module_dir', $this->_path);
        $this->smarty->assign('total', $total);

        $link = new Link();
        $cms_link = $link->getCMSLink('9', null, null, $this->context->cookie->id_lang);
        $this->smarty->assign('cms_link', $cms_link);        

        $config['date'] = '%M:%I %p';
        $config['time'] = '%H:%M:%S';
        $this->smarty->assign('config', $config);
        $this->smarty->assign('yesterday', strtotime('0 day'));

        if (in_array($currency->iso_code, $this->limited_currencies) == false)
            return false;

        $this->smarty->assign('module_dir', $this->_path);
        $this->smarty->assign('ipaytotal_reference', $ipaytotal_reference);

        return $this->display(__FILE__, 'views/templates/hook/payment.tpl');
    }

    public function hookPaymentReturn($params)
    {
        if ($this->active == false)
            return;

        $order = $params['order'];

        if ($order->getCurrentOrderState()->id != Configuration::get('PS_OS_ERROR'))
            $this->smarty->assign('status', 'ok');

        // $this->smarty->assign(array(
        //     'id_order' => $order->id,
        //     'reference' => $order->reference,
        //     'params' => $params,
        //     'total' => Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false),
        // ));

        $this->smarty->assign(array(
            'total' => Tools::displayPrice(
                $params['order']->getOrdersTotalPaid(),
                new Currency($params['order']->id_currency),
                false
            ),
            'shop_name' => $this->context->shop->name,
            'status' => 'ok',
            'params' => $params,
            'reference' => $order->reference,
            'id_order' => $params['order']->id,
            'contact_url' => $this->context->link->getPageLink('contact', true)
        ));

        return $this->display(__FILE__, 'views/templates/hook/confirmation.tpl');
    }
}
