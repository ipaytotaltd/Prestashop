<?php
/**
* 2007-2019 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2019 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/
class IpaytotalRedirectModuleFrontController extends ModuleFrontController
{
    /**
     * Do whatever you have to before redirecting the customer on the website of your payment processor.
     */
    public function postProcess()
    {

        $status = Tools::getValue('status');

        if (empty($status)) {
            $cart = Context::getContext()->cart;
            $address_invoice = new Address($cart->id_address_invoice);
            $customer = Context::getContext()->customer;

            $phone = '';
            if (!empty($address_invoice->phone)) {
                $phone = $address_invoice->phone;
            }

            if (!empty($address_invoice->phone_mobile)) {
                $phone = $address_invoice->phone_mobile;
            }

            $state_code = '';

            $id_state = $address_invoice->id_state;

            if (!empty($id_state)) {
                $state = new State($id_state);
                $state_code = $state->iso_code;
            }

            $currency = new Currency($cart->id_currency);

            $country = new Country($address_invoice->id_country);

            $get_order_id = Context::getContext()->cookie->__get('ipaytotal_reference');

            $total = $cart->getOrderTotal();

            $data = [
                'api_key' => Configuration::get('IPAYTOTAL_API_KEY'),
                'response_url' => $this->context->link->getModuleLink('ipaytotal', 'redirect', [], true),
                'first_name' => $customer->firstname,
                'last_name' => $customer->lastname,
                'address' => $address_invoice->address1,
                'sulte_apt_no' => $get_order_id,
                'country' => $country->iso_code,
                'state' => $state_code, 
                'city' => $address_invoice->city,
                'zip' => $address_invoice->postcode,
                'email' => $customer->email,
                'phone_no' => $phone,
                'card_type' => '2', 
                'amount' => $total,
                'currency' => $currency->iso_code,
                'ip_address' => $_SERVER['REMOTE_ADDR'],
                'card_no' => str_replace(' ', '', Tools::getValue('card-number')),
                'ccExpiryMonth' => Tools::getValue('expiry-month'),
                'ccExpiryYear' => '20'.Tools::getValue('expiry-year'),
                'cvvNumber' => Tools::getValue('card-cvc'),
            ];

            $IPAYTOTAL_LIVE_MODE = Configuration::get('IPAYTOTAL_LIVE_MODE');

            if ($IPAYTOTAL_LIVE_MODE == 1) {
                $url = "https://ipaytotal.solutions/api/transaction";
            } else {
                $url = "https://ipaytotal.solutions/api/test/transaction";
            }

            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_HTTPHEADER,[
                'Content-Type: application/json'
            ]);
            $response = curl_exec($curl);
            curl_close($curl);

            $response_data = json_decode($response, true);

            if ($response_data['status'] == '3d_redirect') {
                header("Location: ".$response_data['redirect_3ds_url']);
                exit();
            } else if ($response_data['status'] == 'success') {
                $data = [
                    'order_id' => Tools::getValue('order_id'),
                    'sulte_apt_no' => $get_order_id,
                    'reason' => Tools::getValue('reason'),
                ];

                $validate_url = $this->context->link->getModuleLink('ipaytotal', 'confirmation', $data, true);
                header("Location: ".$validate_url);
                exit();
            } else {

                $response = $response_data['message'];
                return $this->displayError($response);
            }
        } else {

            if ($status == 'success') {
                $data = [
                    'order_id' => Tools::getValue('order_id'),
                    'sulte_apt_no' => Tools::getValue('sulte_apt_no'),
                    'reason' => Tools::getValue('reason'),
                ];

                $validate_url = $this->context->link->getModuleLink('ipaytotal', 'confirmation', $data, true);
                header("Location: ".$validate_url);
                exit;
            }

            if ($status == 'fail') {

                $response = Tools::getValue('reason');
                return $this->displayError($response);
            }
        }
    }

    protected function displayError($message, $description = false)
    {
        /*
         * Create the breadcrumb for your ModuleFrontController.
         */
        $this->context->smarty->assign('path', '
			<a href="' . $this->context->link->getPageLink('order', null, null, 'step=3') . '">' . $this->module->l('Payment') . '</a;>
			<span class="navigation-pipe">&gt;</span>' . $this->module->l('Error'));

        $this->context->smarty->assign('error', $message);

        /*
         * Set error message and description for the template.
         */
        array_push($this->errors, $this->module->l($message), $description);

        //return $this->setTemplate('error.tpl');
        $this->setTemplate('module:ipaytotal/views/templates/front/error.tpl');
    }


}
